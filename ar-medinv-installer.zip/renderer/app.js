const output = document.querySelector("#output");

function log(text) {
  output.textContent += text + "\n";
}

document.querySelector("#btn-detect-ip").onclick = async () => {
  const result = await window.api.runScript("detect_ip.js");
  document.querySelector("#ip").textContent = result.trim();
  log("IP Terdeteksi: " + result.trim());
};

document.querySelector("#btn-generate").onclick = async () => {
  log("Generating ENV...");
  await window.api.runScript("generate_env.js");
  log("ENV created!");

  log("Generating docker-compose...");
  await window.api.runScript("generate_compose.js");
  log("docker-compose.lan.yml created!");
};

document.querySelector("#btn-start").onclick = async () => {
  log("Starting Docker...");
  await window.api.runScript("docker_start.js");
  log("Services started!");
};

document.querySelector("#btn-stop").onclick = async () => {
  log("Stopping Docker...");
  await window.api.runScript("docker_stop.js");
  log("Services stopped.");
};

document.querySelector("#btn-open").onclick = async () => {
  const result = await window.api.runScript("detect_ip.js");
  const ip = result.trim();
  require("electron").shell.openExternal(`http://${ip}:3000`);
};