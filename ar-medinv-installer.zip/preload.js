const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("api", {
  runScript: (script, args) => ipcRenderer.invoke("run-script", script, args)
});