const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { exec } = require('child_process');

function createWindow() {
  const win = new BrowserWindow({
    width: 900,
    height: 600,
    webPreferences: {
      preload: path.join(__dirname, "preload.js")
    }
  });

  win.loadFile("renderer/index.html");
}

app.whenReady().then(createWindow);

ipcMain.handle("run-script", async (event, scriptName, args = []) => {
  return new Promise((resolve, reject) => {
    exec(`node ./scripts/${scriptName} ${args.join(" ")}`, (err, stdout, stderr) => {
      if (err) reject(stderr);
      resolve(stdout);
    });
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});