const fs = require("fs");
const ip = require("ip");

const lanIP = ip.address();

const backendEnv = `
PORT=4000
DB_HOST=db
DB_USER=root
DB_PASS=root
DB_NAME=ar_medinv
JWT_SECRET=lan-mode
`;

const frontendEnv = `
VITE_API_BASE=http://${lanIP}:4000/api
`;

fs.writeFileSync("backend/.env.lan", backendEnv);
fs.writeFileSync("frontend/.env.lan", frontendEnv);

console.log("ENV created for LAN IP:" + lanIP);