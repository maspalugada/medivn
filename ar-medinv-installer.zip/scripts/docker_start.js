const { execSync } = require("child_process");

execSync("docker compose -f docker-compose.lan.yml build", { stdio: "inherit" });
execSync("docker compose -f docker-compose.lan.yml up -d", { stdio: "inherit" });

console.log("Docker started!");