const { execSync } = require("child_process");

execSync("docker compose -f docker-compose.lan.yml down", { stdio: "inherit" });

console.log("Docker stopped!");