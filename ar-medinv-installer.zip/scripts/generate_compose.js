const fs = require("fs");

const compose = `
version: '3.8'
services:
  db:
    image: mysql:8
    environment:
      MYSQL_ROOT_PASSWORD: root
      MYSQL_DATABASE: ar_medinv
    ports:
      - "3306:3306"
    volumes:
      - db_data:/var/lib/mysql
    restart: unless-stopped

  api:
    build: ./backend
    env_file: ./backend/.env.lan
    ports:
      - "4000:4000"
    depends_on:
      - db

  frontend:
    build: ./frontend
    env_file: ./frontend/.env.lan
    ports:
      - "3000:80"
    depends_on:
      - api

volumes:
  db_data:
`;

fs.writeFileSync("docker-compose.lan.yml", compose);
console.log("docker-compose.lan.yml created!");